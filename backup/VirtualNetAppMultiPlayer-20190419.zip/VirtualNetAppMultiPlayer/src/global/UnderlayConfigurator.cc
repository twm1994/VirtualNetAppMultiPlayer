//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//

#include "UnderlayConfigurator.h"
#include "../server/connection.h"

#include "../server/utility.h"
#include "../server/clientserver.h"

#include "../app/ClientApp.h"

using namespace con;

Define_Module(UnderlayConfigurator);

#define LOGIN_PORT 20000

UnderlayConfigurator::UnderlayConfigurator() {
    login_con = NULL;
    lcCreated = 0;
    clientCreated = 0;
    neighborCreated = 0;
    loginMsg = NULL;
}

UnderlayConfigurator::~UnderlayConfigurator() {
    disposeFailures();
    if (loginMsg != NULL) {
        cancelAndDelete(loginMsg);
    }
    if (login_con != NULL) {
        delete login_con;
    }
}

int UnderlayConfigurator::numInitStages() const {
    return 1;
}

void UnderlayConfigurator::initialize(int stage) {
    sockets_init();
    login_con = new con::Connection(PROTOCOL_ID, 512);
    nextFreeAddress = 0x1000001;
    globalNodeList = GlobalNodeListAccess().get();
    parameterList = GlobalParametersAccess().get();
    coordinator = CoordinatorAccess().get();

    WATCH_MAP(death_schedule);

    // initialize clients
//    cMessage* clientInit = new cMessage(msg::CLIENT_INIT);
//    scheduleAt(0, clientInit);

    login_con->setTimeoutMs(0);
    login_con->ServeLogin(LOGIN_PORT);
    cout << "Login Server started" << endl;
    loginLoop = par("login_loop").doubleValue();
    loginMsg = new cMessage(msg::LOGIN_LOOP);
    scheduleAt(simTime() + loginLoop, loginMsg);
}

void UnderlayConfigurator::finish() {
    sockets_cleanup();
}

void UnderlayConfigurator::handleMessage(cMessage* msg) {
    if (msg->isName(msg::FAILURE)) {
        Failure* failure = check_and_cast<Failure*>(msg);
        std::string hostAddress = failure->getHostAddress();
        EV << "[" << simTime() << "s] " << hostAddress << " is failed" << endl;
        IPvXAddress ipAddress(hostAddress.c_str());
        removeNode(ipAddress);
    } else if (msg->isName(msg::CLIENT_INIT)) {
        handleClientInit(msg);
    } else if (msg->isName(msg::LOGIN_LOOP)) {
        handleClientLogin(msg);
    }
}

void UnderlayConfigurator::handleClientLogin(cMessage* msg) {

    u32 data_maxsize = 10000;
    Buffer<u8> data(data_maxsize);
    u32 datasize;
    u16 peer_id;

    try {
        {
//            JMutexAutoLock lock(login_con_mutex);
            datasize = login_con->Receive(peer_id, *data, data_maxsize);
        }
        if (datasize == 4) {
            ToServerCommand command = (ToServerCommand) readU16(&data[0]);
            if (command == TOSERVER_PLAYERPORT) {
                unsigned short port = readS16(&data[2]);

                std::cout << "received TOSERVER_PLAYERPORT from " << peer_id
                        << " for port: " << port << endl;

                // create client
                // initialize clients
                const char* clientType = par("clientType");
                const char* clientName = par("clientName");
                // create a new client
                cModuleType* moduleType = cModuleType::get(clientType);
                cModule* parent = getParentModule();
                // create (possibly compound) module and build its submodules (if any)
                cModule* client = moduleType->create(clientName, parent,
                        clientCreated + 1, clientCreated);
                clientCreated++;
                // set up parameters, if any
                client->finalizeParameters();
                client->buildInside();
                // create activation message
                client->scheduleStart(simTime());
                client->callInitialize(0);
                // configure server port
                check_and_cast<ClientApp*>(client->getSubmodule("app"))->port =
                        port;
                client->callInitialize(1);
                ClientInfo info = coordinator->addClient(client->getFullName());
                // initialize the client location
                client->getDisplayString().setTagArg("p", 0, info.getX());
                client->getDisplayString().setTagArg("p", 1, info.getY());

                // reply to the client
                SharedBuffer<u8> data(2 + 2);
                writeU16(&data[0], TOCLIENT_LOGIN);
                unsigned short reply = 1;
                writeU16(&data[2], reply);
                // Send as unreliable
                login_con->Send(peer_id, 0, data, true);
            }
        }
    } catch (con::InvalidIncomingDataException &e) {
        std::cout << "Login server::Receive(): "
                "InvalidIncomingDataException: what()=" << e.what()
                << std::endl;
    } catch (con::NoIncomingDataException &e) {
        ;
    }
    scheduleAt(simTime() + loginLoop, loginMsg);
}

void UnderlayConfigurator::handleClientInit(cMessage* msg) {
    // create client
    // initialize clients
    {
        const char* clientType = par("clientType");
        const char* clientName = par("clientName");
        // create a new client
        cModuleType* moduleType = cModuleType::get(clientType);
        cModule* parent = getParentModule();
        // create (possibly compound) module and build its submodules (if any)
        cModule* client = moduleType->create(clientName, parent,
                clientCreated + 1, clientCreated);
        clientCreated++;
        // set up parameters, if any
        client->finalizeParameters();
        client->buildInside();
        // create activation message
        client->scheduleStart(simTime());
        client->callInitialize(0);
        client->callInitialize(1);
        ClientInfo info = coordinator->addClient(client->getFullName());
        // initialize the client location
        client->getDisplayString().setTagArg("p", 0, info.getX());
        client->getDisplayString().setTagArg("p", 1, info.getY());
    }

    // create neighbors
    // initialize neighbors
    int neighborNum = getSimulation()->getModuleByPath("FastSMRModel")->par(
            "neighbor_num");
    const char* neighborType = par("neighborType");
    const char* neighborName = par("neighborName");
    for (int i = 0; i < neighborNum; i++) {
        // create a new neighbor
        cModuleType* moduleType = cModuleType::get(neighborType);
        cModule* parent = getParentModule();
        // create (possibly compound) module and build its submodules (if any)
        cModule* neighbor = moduleType->create(neighborName, parent,
                neighborCreated + 1, neighborCreated);
        neighborCreated++;
        // set up parameters, if any
        neighbor->finalizeParameters();
        neighbor->buildInside();
        // create activation message
        neighbor->scheduleStart(simTime());
        neighbor->callInitialize(0);
        neighbor->callInitialize(1);
        // initialize the client location
        ClientInfo info = coordinator->getClientInfo(neighbor->getFullName());
        neighbor->getDisplayString().setTagArg("p", 0, info.getX());
        neighbor->getDisplayString().setTagArg("p", 1, info.getY());
    }

    delete msg;
}

TransportAddress* UnderlayConfigurator::createLogicComputer() {
    const char* hostType = par("meshType");
    const char* hostName = par("meshName");

    // create a new node
    cModuleType *moduleType = cModuleType::get(hostType);
    cModule* parent = getParentModule();
    // create (possibly compound) module and build its submodules (if any)
    cModule *LC = moduleType->create(hostName, parent, lcCreated + 1,
            lcCreated);
    lcCreated++;
    // set up parameters, if any
    LC->finalizeParameters();
    LC->buildInside();
    // create activation message
    LC->scheduleStart(simTime());
    LC->callInitialize(0);

    // create address for the Rendezvous node
    IPvXAddress addr = IPAddress(nextFreeAddress++);
    cModule* rendezvous = LC->getSubmodule("rendezvous");
    HostBase* rendezvousCtrl = check_and_cast<HostBase*>(
            rendezvous->getSubmodule("ctrl"));
    rendezvousCtrl->setIPAddress(addr);
    LC->callInitialize(1);

    // place the logical computer
    long x = coordinator->random_LC_X();
    long y = coordinator->random_LC_Y();
    LC->getDisplayString().setTagArg("p", 0, x);
    LC->getDisplayString().setTagArg("p", 1, y);

    // create meta information
    SimpleNodeEntry* entry = new SimpleNodeEntry(rendezvous);
    SimpleInfo* info = new SimpleInfo(rendezvous->getId(),
            rendezvous->getFullName());
    info->setEntry(entry);
    //add host to bootstrap oracle
    globalNodeList->addPeer(addr, info);

    TransportAddress *address = new TransportAddress(addr);
    return address;
}

TransportAddress* UnderlayConfigurator::registerEndpoint(cModule* host) {
    IPvXAddress addr = IPAddress(nextFreeAddress++);
    // create meta information
    SimpleNodeEntry* entry = new SimpleNodeEntry(host);
    SimpleInfo* info = new SimpleInfo(host->getId(), host->getFullName());
    info->setEntry(entry);
    //add node to bootstrap oracle
    globalNodeList->addPeer(addr, info);

    TransportAddress *address = new TransportAddress(addr);
    return address;
}

TransportAddress* UnderlayConfigurator::createNode(cModule* parent,
        int nodeCreated) {
    Enter_Method_Silent("Create a new node");

    const char* hostType = par("nodeType");
    const char* hostName = par("nodeName");

    // create a new node
    cModuleType *moduleType = cModuleType::get(hostType);
    // create (possibly compound) module and build its submodules (if any)
    cModule *host = moduleType->create(hostName, parent, nodeCreated + 1,
    nodeCreated);
    std::string nodeName = host->getFullName();
    EV << "[" << simTime() << "s] create host: " << nodeName << endl;

    // set up parameters, if any
    host->finalizeParameters();
    host->buildInside();
    // create activation message
    host->scheduleStart(simTime());
    host->callInitialize(0);

    IPvXAddress addr = IPAddress(nextFreeAddress++);
    IPv4InterfaceData* ipData = new IPv4InterfaceData();
    ipData->setIPAddress(addr.get4());
    InterfaceEntry* ie = new InterfaceEntry();
    std::string IPInterface = host->par("IPInterface");
    ie->setName(IPInterface.c_str());
    ie->setIPv4Data(ipData);
    InterfaceTable* ift = InterfaceTableAccess().get(host);
    ift->addInterface(ie);
    host->callInitialize(1);
    // create meta information
    SimpleNodeEntry* entry = new SimpleNodeEntry(host);
    SimpleInfo* info = new SimpleInfo(host->getId(), host->getFullName());
    info->setEntry(entry);
    //add node to bootstrap oracle
    globalNodeList->addPeer(addr, info);

    // time for node failure
    Failure* failure = new Failure(msg::FAILURE);
    std::string addrStr = addr.get4().str();
    failure->setHostAddress(addrStr.c_str());
    failures[addrStr] = failure;
    simtime_t lifespan = ChurnGeneratorAccess().get()->getSessionLength();
    simtime_t deathTime = simTime() + lifespan;
    scheduleAt(deathTime, failure);
    death_schedule[addrStr] = deathTime;
    TransportAddress *address = new TransportAddress(addr);
    return address;
}

void UnderlayConfigurator::removeNode(IPvXAddress& nodeAddr) {
    SimpleInfo* info = dynamic_cast<SimpleInfo*>(globalNodeList->getPeerInfo(
            nodeAddr));
    if (info != nullptr) {
        SimpleNodeEntry* destEntry = info->getEntry();
        cModule* node = destEntry->getUdpIPv4Gate()->getOwnerModule();
        node->callFinish();
        node->deleteModule();
        globalNodeList->killPeer(nodeAddr);
        parameterList->remoteHost(nodeAddr);
        std::string addr = nodeAddr.get4().str();
        Failure* failure = failures[addr];
        cancelAndDelete(failure);
        failures.erase(nodeAddr.get4().str());
    }
}

void UnderlayConfigurator::removeLogicComputer(IPvXAddress& rendezvousAddr) {
    SimpleInfo* info = dynamic_cast<SimpleInfo*>(globalNodeList->getPeerInfo(
            rendezvousAddr));
    SimpleNodeEntry* destEntry = info->getEntry();
    cModule* LC =
            destEntry->getUdpIPv4Gate()->getOwnerModule()->getParentModule()->getParentModule();
    LC->callFinish();
    LC->deleteModule();
    globalNodeList->killPeer(rendezvousAddr);
    parameterList->remoteHost(rendezvousAddr);
}

void UnderlayConfigurator::revokeNode(IPvXAddress& nodeAddr) {
    Enter_Method_Silent("Revoke a node");

    std::string hostAddress = nodeAddr.get4().str();
    Failure* failure = failures[hostAddress];
    if (failure != NULL) {
        cancelEvent(failure);
    }
    scheduleAt(simTime(), failure);
}

void UnderlayConfigurator::disposeFailures() {
    try {
        for (std::map<std::string, Failure*>::iterator it = failures.begin();
                it != failures.end(); ++it) {
            Failure* failure = it->second;
            if (failure != NULL) {
                cancelAndDelete(failure);
            }
        }
        failures.clear();
    } catch (exception& e) {
        EV << e.what() << endl;
    }
}
