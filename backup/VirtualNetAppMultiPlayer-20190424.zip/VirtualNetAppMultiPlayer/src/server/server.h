#ifndef SERVER_HEADER
#define SERVER_HEADER

#include "connection.h"
#include "environment.h"

#include <iostream>
#include "utility.h"
#include "clientserver.h"
#include "../thread/jmutexautolock.h"
#include "map.h"

using namespace jthread;

#ifdef _WIN32
#include <windows.h>
#define sleep_ms(x) Sleep(x)
#else
#include <unistd.h>
#define sleep_ms(x) usleep(x*1000)
#endif

class Server;

class ServerNetworkThread: public JThread {
    bool run;
    JMutex run_mutex;

    Server *m_server;

public:

    ServerNetworkThread(Server *server) :
            JThread(), run(true), m_server(server) {
        run_mutex.Init();
    }

    /*
     * thread run method:
     * 1) Receive and handle network packets;
     * 2) Handle network timeouts;
     * 3) Send player positions.
     */
    void * Thread();

    bool getRun() {
        run_mutex.Lock();
        bool run_cached = run;
        run_mutex.Unlock();
        return run_cached;
    }
    void setRun(bool a_run) {
        run_mutex.Lock();
        run = a_run;
        run_mutex.Unlock();
    }
};

class Server {
public:
    /*
     NOTE: Every public method should be thread-safe
     */
    Server();
    ~Server();
    void start(unsigned short port);
    void stop();
    // server environment simulation proceeds (in the main loop)
    void step(float dtime);
    void AsyncRunStep();
    void Receive();
    // handle the received data
    void ProcessData(u8 *data, u32 datasize, u16 peer_id);
private:

    void SendPlayerPositions(float dtime);

    Environment m_env;
    JMutex m_env_mutex;

    con::Connection m_con;
    JMutex m_con_mutex;

    float m_step_dtime;
    JMutex m_step_dtime_mutex;

    ServerNetworkThread m_thread;
};

#endif

