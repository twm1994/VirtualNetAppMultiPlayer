//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "NodeApp.h"
#include "ClientApp.h"

Define_Module(NodeApp);

NodeApp::NodeApp() :
        m_env(new MasterMap(), std::cout), position(3) {
    lastApplied = -1;
    initial_state = 0;
    STAGE_NUM = stage::NODE_APP_INIT;
    peer_id = 0;
    skin = 1;
    gear = 0;
    version = 0;
    reqId = 0;
}

NodeApp::~NodeApp() {
    ;
}

int NodeApp::numInitStages() const {
    return STAGE_NUM;
}

void NodeApp::initialize(int stage) {
    if (stage == 0) {
        HostBase::initialize();
        fullName = getParentModule()->getFullName();
        step_timer =
                getParentModule()->getSubmodule("ctrl")->par("roundCycle").doubleValue();

        WATCH(lastApplied);
        WATCH(initial_state);
        WATCH_MAP(Qa_key);
        WATCH_MAP(Qa);
        WATCH_MAP(Qs);
        WATCH(peer_id);
        WATCH_VECTOR(position);
        WATCH(skin);
        WATCH(gear);
        WATCH(version);
    }
    if (stage == 1) {
        // create the host information for the P2P cloud service
        ipAddress = loadIPAddress(getParentModule()->par("IPInterface"),
                getParentModule());
        id = util::getSHA1(ipAddress.get4().str() + "4000",
                GlobalParametersAccess().get()->getAddrSpaceSize());
        SimpleNodeEntry* entry = new SimpleNodeEntry(this->getParentModule());
        HostInfo* info = new HostInfo(this->getParentModule()->getId(),
                this->getParentModule()->getFullName());
        info->setHostId(id);
        info->setEntry(entry);
        //add host to bootstrap oracle
        GlobalNodeListAccess().get()->addPeer(ipAddress, info);
    }
}

void NodeApp::dispatchHandler(cMessage *msg) {
    if (msg->isName(msg::EVENT_APPLY)) {
        EventApply* eventApply = check_and_cast<EventApply*>(msg);
        applyEvent(eventApply);
    } else if (msg->isName(msg::INIT_APP)) {
        InitApp* initApp = check_and_cast<InitApp*>(msg);
        handleInitApp(initApp);
    } else if (msg->isName(msg::CHORD_REPLY)) {
        ChordMessage* chordMsg = check_and_cast<ChordMessage*>(msg);
        handleChordMsg(chordMsg);
    }
}

void NodeApp::handleInitApp(InitApp* initApp) {
    this->peer_id = initApp->getPeerId();
    reqId = util::getSHA1(std::to_string(peer_id),
            GlobalParametersAccess().get()->getAddrSpaceSize());
    // query data from P2P cloud
    ChordInfo* chord = NULL;
    do {
        chord = GlobalNodeListAccess().get()->randChord();
    } while (chord == NULL
            || !GlobalNodeListAccess().get()->isReady(chord->getChordId()));
    ChordMessage* message = new ChordMessage(msg::CHORD_LOOK_UP);
    message->setSender(id);
    message->setHop(1);
    message->setType(ChordMsgType::CHORD_GET);
    message->setLabel(msg::LABEL_CONTENT);
    message->setKey(reqId);
    message->setContent("");
    UDPControlInfo* udpControlInfo = new UDPControlInfo();
    udpControlInfo->setDestAddr(
            GlobalNodeListAccess().get()->getNodeAddr(chord->getChordId()));
    udpControlInfo->setSrcAddr(ipAddress);
    message->setControlInfo(udpControlInfo);
    send(message, gateHalf("link", cGate::OUTPUT));

    delete initApp;
}

void NodeApp::handleChordMsg(ChordMessage* chordMsg) {
    int type = chordMsg->getType();
    if (type == ChordMsgType::CHORD_GET_REPLY) {
        std::string content = chordMsg->getContent();
        if (content.compare(data::DATA_EMPTY) != 0) {
            PlayerState ps;
            ps.deserialize(content);
            this->position = ps.position;
            this->skin = ps.skin;
            this->gear = ps.gear;
            this->version = ps.version;
        } else {
            std::cout << data::DATA_EMPTY << endl;
        }
    } else if (type == ChordMsgType::CHORD_STORE_REPLY) {
        toExit = true;
        IPvXAddress rendezvous = loadIPAddress(
                getParentModule()->par("RendezvousInterface"),
                getParentModule());
        cMessage* msg = new cMessage(msg::TERMINATION);
        UDPControlInfo* udpControlInfo = new UDPControlInfo();
        udpControlInfo->setDestAddr(rendezvous);
        udpControlInfo->setSrcAddr(ipAddress);
        msg->setControlInfo(udpControlInfo);
        send(msg, gateHalf("link", cGate::OUTPUT));
    }

    delete chordMsg;
}

// for event handling ============================================

void NodeApp::applyEvent(EventApply* eventApply) {
    // simulation step-wise advancement

    // step interval, in seconds
    double dtime = step_timer.dbl();
    m_env.step(dtime);

    // handle events

    // deliver event to the application layer
    std::string content = eventApply->getEvent();

    cout << "app data content: " << content << endl;

    int index = -1;
    if (!Qa.empty()) {
        index = Qa.rbegin()->first;
    }
    index++;
    Qa[index] = content;
    boost::tuple<int, unsigned long, int> key(eventApply->getRound(),
            eventApply->getClientId(), eventApply->getSequence());
    Qa_key[index] = key;

    // handle events at application layer
    std::map<int, std::string>::iterator it2 = Qa.begin();
    if (lastApplied != -1) {
        it2 = Qa.find(lastApplied);
        it2++;
    }
    for (; it2 != Qa.end(); it2++) {
        int index2 = it2->first;
        lastApplied = index2;
        std::string event = it2->second;
        boost::tuple<int, unsigned long, int> eventKey = Qa_key[index2];

        std::string newState;
        if (Qs.empty()) {
            unsigned long input = sdbm::encode(event.c_str());
            newState = util::longToStr(initial_state) + util::longToStr(input);
        } else {
            std::map<int, unsigned long>::reverse_iterator last = Qs.rbegin();
            unsigned long lastState = last->second;
            EV << "[Debug] lastState = " << lastState << endl;
            unsigned long input = sdbm::encode(event.c_str());
            EV << "[Debug] input = " << input << endl;
            newState = util::longToStr(lastState) + util::longToStr(input);
            EV << "[Debug] newState = " << newState << endl;
        }
        Qs[index2] = sdbm::encode(newState.c_str());
        unsigned long state = Qs[index2];

        // generate response message
        std::string response = "";
        if (event.find(event::TO_REMOVE) == 0) {
            std::vector<std::string> container;
            util::splitString(event, "+", container);
            unsigned short peerId = util::strToUShort(container[1]);
            std::string neighbor = container[2];
            std::string clientId = container[3];
            std::string result = removeNeighbor(peerId, clientId);
            if (!result.empty()) {
                response = result + "+" + event::TO_REMOVE + "+" + neighbor;
            }
        } else {
            std::vector<std::string> container;
            util::splitString(event, "+", container);
            std::string encoded = container[0];
            int datasize = util::strToInt(container[1]);
            unsigned char decoded[datasize];
            util::string_to_binary(encoded, decoded, datasize);
            if (container.size() == 5) {
                unsigned short peerId = util::strToUShort(container[2]);
                std::string neighbor = container[3];
                std::string clientId = container[4];
                std::string result = processData(decoded, datasize, peerId,
                        clientId);
                if (!result.empty()) {
                    response = result + "+" + event::TO_JOIN + "+" + neighbor;

                    std::cout << fullName << " response result: " << response << endl;
                }
            } else if (container.size() == 4) {
//                peer_id = util::strToUShort(container[2]);
                std::string clientId = container[3];
                response = processData(decoded, datasize, peer_id, clientId);
            } else {
                response = processData(decoded, datasize);
            }
        }

        // assign update to the queues in Qsend
        if (!response.empty()) {  // in case of TOSERVER_PLAYERPOS command
            UpdateApply* update = new UpdateApply(msg::UPDATE_APPLY);
            update->setEvent(response.c_str());
            update->setRound(get<0>(eventKey));
            update->setClientId(get<1>(eventKey));
            update->setSequence(get<2>(eventKey));
            update->setState(state);
            send(update, gateHalf("link", cGate::OUTPUT));
        }
    } // end of the event apply loop

    delete eventApply;
}

std::string NodeApp::removeNeighbor(u16 peerId, std::string clientId) {

//    std::cout << "Server::removeNeighbor(): RMPLAYER" << std::endl;

    SharedBuffer<u8> reply(2 + 2);
    writeU16(&reply[0], TOCLIENT_RMPLAYER);
    writeU16(&reply[2], peerId);
    // Send as unreliable
//            m_con.Send(peerId, 1, reply, true);
    std::string response;
    util::binary_to_string(*reply, reply.getSize(), response);
    // go through channel 0
    std::string encoded = response + "+" + std::to_string(reply.getSize()) + "+"
            + "0" "+" + clientId;
    return encoded;
}

std::string NodeApp::processData(u8 *data, u32 datasize, u16 peerId,
        std::string clientId) {
    // Let free access to the environment and the connection
//    JMutexAutoLock envlock(m_env_mutex);
//    JMutexAutoLock conlock(m_con_mutex);

    try {

        if (datasize < 2)
            return "";

        ToServerCommand command = (ToServerCommand) readU16(&data[0]);

        if (command == TOSERVER_GETBLOCK) {

            // Check for too short data
            if (datasize < 8)
                return "";
            std::cout << "Server::ProcessData(): GETBLOCK" << std::endl;
            /*
             Get block data and send it
             */
            v3s16 p;
            p.X = readS16(&data[2]);
            p.Y = readS16(&data[4]);
            p.Z = readS16(&data[6]);
            MapBlock *block = m_env.getMap().getBlock(p);

            u32 replysize = 8 + MapBlock::serializedLength();
            SharedBuffer<u8> reply(replysize);
            writeU16(&reply[0], TOCLIENT_BLOCKDATA);
            writeS16(&reply[2], p.X);
            writeS16(&reply[4], p.Y);
            writeS16(&reply[6], p.Z);
            block->serialize(&reply[8]);
            // Send as unreliable
//            m_con.Send(peerId, 1, reply, true);
            std::string response;
            util::binary_to_string(*reply, reply.getSize(), response);
            // go through channel 1
            std::string encoded = response + "+"
                    + std::to_string(reply.getSize()) + "+" + "1" + "+"
                    + event::GET_BLOCK + "+" + clientId;
            return encoded;
        } else if (command == TOSERVER_REMOVENODE) {

//            std::cout << "Server::ProcessData(): ADDNODE" << std::endl;

            if (datasize < 8)
                return "";

            v3s16 p;
            p.X = readS16(&data[2]);
            p.Y = readS16(&data[4]);
            p.Z = readS16(&data[6]);

            MapNode n;
            n.d = MATERIAL_AIR;
            m_env.getMap().setNode(p, n);

            u32 replysize = 8;
            SharedBuffer<u8> reply(replysize);
            writeU16(&reply[0], TOCLIENT_REMOVENODE);
            writeS16(&reply[2], p.X);
            writeS16(&reply[4], p.Y);
            writeS16(&reply[6], p.Z);
            // Send as reliable
//            m_con.SendToAll(0, reply, true);
            std::string response;
            util::binary_to_string(*reply, reply.getSize(), response);
            // go through channel 0
            std::string encoded = response + "+"
                    + std::to_string(reply.getSize()) + "+" + "0";
            return encoded;
        } else if (command == TOSERVER_ADDNODE) {

//            std::cout << "Server::ProcessData(): ADDNODE" << std::endl;

            if (datasize < 8 + MapNode::serializedLength())
                return "";

            v3s16 p;
            p.X = readS16(&data[2]);
            p.Y = readS16(&data[4]);
            p.Z = readS16(&data[6]);

            MapNode n;
            n.deSerialize(&data[8]);
            m_env.getMap().setNode(p, n);

            u32 replysize = 8 + MapNode::serializedLength();
            SharedBuffer<u8> reply(replysize);
            writeU16(&reply[0], TOCLIENT_ADDNODE);
            writeS16(&reply[2], p.X);
            writeS16(&reply[4], p.Y);
            writeS16(&reply[6], p.Z);
            n.serialize(&reply[8]);
            // Send as reliable
//            m_con.SendToAll(0, reply, true);
            std::string response;
            util::binary_to_string(*reply, reply.getSize(), response);
            // go through channel 0
            std::string encoded = response + "+"
                    + std::to_string(reply.getSize()) + "+" + "0";
            return encoded;
        } else if (command == TOSERVER_PLAYERPOS) {
            if (datasize < 2 + 12 + 12 + 12 + 2 + 2)
                return "";

            cout << "Server::ProcessData(): update player position" << endl;

            Player *player = m_env.getPlayer(peerId);

            // Create a player if it doesn't exist
            if (player == NULL) {
                std::cout << "Server::ProcessData(): Adding player " << peerId
                        << std::endl;
                player = new Player(false);
                player->peer_id = peerId;
                m_env.addPlayer(player);
            }

            // TODO: player couter is not needed
            player->timeout_counter = 0.0;

            // update position and speed
            v3s32 ps = readV3S32(&data[2]);
            v3s32 ss = readV3S32(&data[2 + 12]);
            v3s32 rs = readV3S32(&data[2 + 12 + 12]);
            v3f position((f32) ps.X / 100., (f32) ps.Y / 100.,
                    (f32) ps.Z / 100.);
            v3f speed((f32) ss.X / 100., (f32) ss.Y / 100., (f32) ss.Z / 100.);
            v3f rotation((f32) rs.X / 100., (f32) rs.Y / 100.,
                    (f32) rs.Z / 100.);
            player->setPosition(position);
            player->speed = speed;
            player->setRotation(rotation);

            // update state
            this->position[0] = position.X;
            this->position[1] = position.Y;
            this->position[2] = position.Z;
            skin = readU16(&data[2 + 12 + 12 + 12]);
            gear = readU16(&data[2 + 12 + 12 + 12 + 2]);
            version++;

            // generate the player position update command
//            cout << "player position:" << position.X << ", " << position.Y
//                    << ", " << position.Z << endl;
//            cout << "player skin:" << skin << endl;
//            cout << "player gear:" << gear << endl;

            u32 datasize = 2 + 2 + 12 + 12 + 12 + 2 + 2;
            SharedBuffer<u8> reply(datasize);
            writeU16(&reply[0], TOCLIENT_PLAYERPOS);
            u32 start = 2;
            v3f pf = player->getPosition();
            v3s32 position2(pf.X * 100, pf.Y * 100, pf.Z * 100);
            // TODO: here, speed may be set to 0
            v3f sf = player->speed;
            v3s32 speed2(sf.X * 100, sf.Y * 100, sf.Z * 100);
            v3f rf = player->getRotation();
            v3s32 rotation2(rf.X * 100, rf.Y * 100, rf.Z * 100);
            writeU16(&reply[start], player->peer_id);
            writeV3S32(&reply[start + 2], position2);
            writeV3S32(&reply[start + 2 + 12], speed2);
            writeV3S32(&reply[start + 2 + 12 + 12], rotation2);
            // send player state
            writeU16(&reply[start + 2 + 12 + 12 + 12], skin);
            writeU16(&reply[start + 2 + 12 + 12 + 12 + 2], gear);
            // Send as reliable
            //            m_con.SendToAll(0, data, false)
            std::string response;
            util::binary_to_string(*reply, reply.getSize(), response);
            // go through channel 0
            std::string encoded = response + "+"
                    + std::to_string(reply.getSize()) + "+" + "0" + "+"
                    + clientId;

            cout << "command for adding new player: " << encoded << endl;

            return encoded;

        } else if (command == TOSERVER_EXIT) {

            // Check for too short data
            if (datasize < 18)
                return "";
            std::cout << "Server::ProcessData(): CLIENT_EXIT" << std::endl;

            // update position and speed
            v3s32 ps = readV3S32(&data[2]);
            v3f p((f32) ps.X / 100., (f32) ps.Y / 100., (f32) ps.Z / 100.);
            position[0] = p.X;
            position[1] = p.Y;
            position[2] = p.Z;
            skin = readU16(&data[2 + 12]);
            gear = readU16(&data[2 + 12 + 2]);
            version++;

            onExit();
        } else {
            std::cout << "WARNING: Server::ProcessData(): Ingoring "
                    "unknown command " << command << std::endl;
        }

    } //try
    catch (SendFailedException &e) {
        std::cout << "Server::ProcessData(): SendFailedException: " << "what="
                << e.what() << std::endl;
    }
    return "";
}

void NodeApp::onExit() {

    // store state to the P2P cloud
    ChordInfo* chord = NULL;
    do {
        chord = GlobalNodeListAccess().get()->randChord();
    } while (chord == NULL
            || !GlobalNodeListAccess().get()->isReady(chord->getChordId()));

    ChordMessage* message = new ChordMessage(msg::CHORD_LOOK_UP);
    message->setSender(id);
    message->setHop(0);
    message->setType(ChordMsgType::CHORD_STORE);
    message->setKey(reqId);
    PlayerState ps;
    ps.position = this->position;
    ps.version = this->version;
    ps.gear = this->gear;
    ps.skin = this->skin;
    std::string serialized = ps.serialize();
    message->setContent(serialized.c_str());
    message->setByteLength(serialized.length());
    message->setLabel(msg::LABEL_CONTENT);
    IPvXAddress destAddr = GlobalNodeListAccess().get()->getNodeAddr(
            chord->getChordId());
    UDPControlInfo* udpControlInfo = new UDPControlInfo();
    udpControlInfo->setDestAddr(destAddr);
    message->setControlInfo(udpControlInfo);
    send(message, gateHalf("link", cGate::OUTPUT));
}

// for state recovery ============================================

std::string NodeApp::packState() {
    core::list<Player*> players = m_env.getPlayers();
    std::vector<std::string> playerStates;
    for (auto player : players) {
        std::string playerState = packPlayer(*player);
        playerStates.push_back(playerState);
    }
    stringstream ss;
    for (auto player : playerStates) {
        ss << player << "+";
    }
    std::string state = ss.str();

    // TODO to pack map state

    return state;
}

std::string NodeApp::packPlayer(Player& player) {

    std::vector<std::string> states(10);
    states[0] = std::to_string(player.speed.X);
    states[1] = std::to_string(player.speed.Y);
    states[2] = std::to_string(player.speed.Z);
    states[3] = std::to_string(player.touching_ground);
    states[4] = std::to_string(player.peer_id);
    states[5] = std::to_string(player.timeout_counter);
    states[6] = std::to_string(player.isLocal());
    states[7] = std::to_string(player.getPosition().X);
    states[8] = std::to_string(player.getPosition().Y);
    states[9] = std::to_string(player.getPosition().Z);

    stringstream ss;
    ss << states[0] << "|" << states[1] << "|" << states[2] << "|" << states[3]
            << "|" << states[4] << "|" << states[5] << "|" << states[6] << "|"
            << states[7] << "|" << states[8] << "|" << states[9];

    return ss.str();
}

void NodeApp::buildEnvironment(Map* map) {
    // TODO to reduce the work of map state save & load
    this->m_env.setMap(map);
}

void NodeApp::addPlayer(v3f speed, bool touching_ground, u16 peerId,
        float timeout_counter, bool is_local, v3f position, v3f rotation) {
    Player player(speed, touching_ground, peerId, timeout_counter, is_local,
            position, rotation);
    this->m_env.addPlayer(&player);
}

void NodeApp::initState(unsigned long state) {
    this->initial_state = state;
    Qs.clear();
    Qa.clear();
    Qa_key.clear();
    lastApplied = -1;
}
